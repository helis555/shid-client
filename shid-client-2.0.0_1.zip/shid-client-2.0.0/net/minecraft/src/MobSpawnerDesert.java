package net.minecraft.src;

public class MobSpawnerDesert extends MobSpawnerBase {
}
