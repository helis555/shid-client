package net.minecraft.src;

public class KeyBinding {
	public String keyDescription;
	public int keyCode;

	public KeyBinding(String var1, int var2) {
		this.keyDescription = var1;
		this.keyCode = var2;
	}
}
