package net.minecraft.src;

public class MinecraftError extends Error {
}
