package net.minecraft.src;

public abstract class NoiseGenerator {
}
