package net.minecraft.src;

import java.net.URL;

public class SoundPoolEntry {
	public String soundName;
	public URL soundUrl;

	public SoundPoolEntry(String var1, URL var2) {
		this.soundName = var1;
		this.soundUrl = var2;
	}
}
