package net.minecraft.src;

public abstract class ModelBase {
	public float field_1244_k;
	public boolean field_1243_l = false;

	public void render(float var1, float var2, float var3, float var4, float var5, float var6) {
	}

	public void setRotationAngles(float var1, float var2, float var3, float var4, float var5, float var6) {
	}
}
