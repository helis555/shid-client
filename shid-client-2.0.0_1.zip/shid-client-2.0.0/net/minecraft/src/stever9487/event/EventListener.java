package net.minecraft.src.stever9487.event;

public interface EventListener<T extends Event> {
    void handleEvent(T var1);
}
