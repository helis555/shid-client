package net.minecraft.src.stever9487.event;

public class Event {
    public boolean isPre = false;
    public boolean isCancelled = false;
}
