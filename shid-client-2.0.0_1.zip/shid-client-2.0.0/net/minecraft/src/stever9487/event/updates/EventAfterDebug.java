package net.minecraft.src.stever9487.event.updates;

import net.minecraft.src.stever9487.event.Event;

public class EventAfterDebug extends Event {
}
