package net.minecraft.src.stever9487.commands.cmds;

import net.minecraft.src.stever9487.commands.Command;

public class Template extends Command {
    public Template() {
        super("name", "description", "syntax", "alias");
    }

    public void onCommand(String[] args, String command){

    }
}