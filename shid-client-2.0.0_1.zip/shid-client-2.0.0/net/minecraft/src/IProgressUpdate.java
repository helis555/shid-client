package net.minecraft.src;

public interface IProgressUpdate {
	void func_594_b(String var1);

	void displayLoadingString(String var1);

	void setLoadingProgress(int var1);
}
