package net.minecraft.src;

public enum EnumSkyBlock {
	Sky(15),
	Block(0);

	public final int field_1722_c;

	private EnumSkyBlock(int var3) {
		this.field_1722_c = var3;
	}
}
