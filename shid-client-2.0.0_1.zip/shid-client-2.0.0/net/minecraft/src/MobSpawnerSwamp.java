package net.minecraft.src;

public class MobSpawnerSwamp extends MobSpawnerBase {
}
